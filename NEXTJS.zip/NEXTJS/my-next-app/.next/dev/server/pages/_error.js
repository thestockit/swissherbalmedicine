var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/e2179_08628b0d._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/e2179_603c8b6b._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/e2179_next_f987d229._.js")
R.m("[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/OneDrive/Desktop/NEXTJS/my-next-app/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
