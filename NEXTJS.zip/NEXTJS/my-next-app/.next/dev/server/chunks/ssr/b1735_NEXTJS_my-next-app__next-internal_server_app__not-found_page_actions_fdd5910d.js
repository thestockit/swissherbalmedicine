module.exports = [
"[project]/OneDrive/Desktop/NEXTJS/my-next-app/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=b1735_NEXTJS_my-next-app__next-internal_server_app__not-found_page_actions_fdd5910d.js.map