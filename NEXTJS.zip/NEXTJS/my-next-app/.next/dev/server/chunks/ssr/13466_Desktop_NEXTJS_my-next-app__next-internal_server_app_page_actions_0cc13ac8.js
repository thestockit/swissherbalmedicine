module.exports = [
"[project]/OneDrive/Desktop/NEXTJS/my-next-app/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Desktop_NEXTJS_my-next-app__next-internal_server_app_page_actions_0cc13ac8.js.map