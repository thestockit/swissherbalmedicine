module.exports = [
"[project]/OneDrive/Desktop/NEXTJS/my-next-app/.next-internal/server/app/team/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=13466_Desktop_NEXTJS_my-next-app__next-internal_server_app_team_page_actions_5e3e2ee6.js.map