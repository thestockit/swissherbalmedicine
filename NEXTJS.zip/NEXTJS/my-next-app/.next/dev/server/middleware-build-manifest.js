globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/e2179_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e6b9ca04._.js",
    "static/chunks/e2179_next_dist_compiled_react-dom_30b42d14._.js",
    "static/chunks/e2179_next_dist_compiled_react-server-dom-turbopack_c63184fc._.js",
    "static/chunks/e2179_next_dist_compiled_next-devtools_index_fb0de0da.js",
    "static/chunks/e2179_next_dist_compiled_bcced940._.js",
    "static/chunks/e2179_next_dist_client_fe69f67c._.js",
    "static/chunks/e2179_next_dist_921f6fd4._.js",
    "static/chunks/e2179_@swc_helpers_cjs_1f425d2a._.js",
    "static/chunks/OneDrive_Desktop_NEXTJS_my-next-app_a0ff3932._.js",
    "static/chunks/turbopack-OneDrive_Desktop_NEXTJS_my-next-app_8df02251._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];